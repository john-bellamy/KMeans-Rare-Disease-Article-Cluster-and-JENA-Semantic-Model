#!/bin/sh
cd bin; java JenaModelCreationMain;
#cd ../fuseki; bash fuseki-server --loc=DB --update /pubmedArticles/data
#cd fuseki; bash fuseki-server --config=./huntMS.ttl   

