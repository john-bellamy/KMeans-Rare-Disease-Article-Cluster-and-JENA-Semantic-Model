import java.io.IOException;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.Property;

import model.DefaultModelMaker;
import model.RareDiseaseReasoner;
import model.PersistModel;


public class JenaModelCreationMain {
	
	//Shared fields

	
	static Property Title, ShortDetails, KeyWords;
	
	//Fields for SBMA
	static String pubmedUri = "http://www.ncbi.nlm.nih.gov/pubmed/";
	static DefaultModelMaker sbma = new DefaultModelMaker();
    static Model sbmaArticles = null;    
    
    //Fields for Hunter's
    static String pubmedUri2 = "http://www.ncbi.nlm.nih.gov/pubmed/#";
    static DefaultModelMaker hunter = new DefaultModelMaker();
    static Model hunterArticles = null;
 
   public static void main(String[] args) throws IOException {
		//Variables for both models
	
		String directory = "fuseki/DB";
		String sharedOwlOutputFileName = "fuseki/data/shared_reasoned.ttl";
	
		//Variables for sbma
	
		String sbmaFileName = "inputData/wian_keyword_frame.csv";
		String sbmaOutputFileName = "outputData/sbma.ttl";
	    String sbmaOwlFile = "inputData/sbma.owl";
		
	    // Variables for hunter's
	    String hunterFileName = "inputData/hunter_keyword_frame.csv";
		String hunterOutputFileName = "outputData/hunter.ttl";
	    String hunterOwlFile = "inputData/hunter.owl"; 
		//String hunterTtlOutputFileName = "outputData/hunter_reasoned.ttl";
		
		//Create URI for models
		System.out.println("Setting model URI");
		sbma.setUri(pubmedUri);
		hunter.setUri(pubmedUri2);
		
		System.out.println("Creating default models");
		// Create default model
		sbma.createDefaultModel(sbmaArticles);
		hunter.createDefaultModel(hunterArticles);
		
		//Create prefix for models
	    sbma.setPrefix("sbma");
	    hunter.setPrefix("hunter");
	    
	    System.out.println("Setting property names for model...");
		// Set property names for model population
		sbma.setPropertyName("Title", "ShortDetails", "KeyWords");
		hunter.setPropertyName("Title", "ShortDetails", "KeyWords");
		
		System.out.println("Setting properties for model...");
		// Set properties for model population
		sbma.setProperty(Title, ShortDetails, KeyWords);
		hunter.setProperty(Title, ShortDetails, KeyWords);
		
		System.out.println("Populating model from csv...");
		// Populate model from csv
		sbma.readCsv(sbmaFileName, sbmaOutputFileName);
		hunter.readCsv(hunterFileName, hunterOutputFileName);
		
		
		//Reason over rdf files created
		RareDiseaseReasoner.rdfOwlReasoner(sbmaOutputFileName, hunterOutputFileName,
				sbmaOwlFile, hunterOwlFile, sharedOwlOutputFileName); 
        
		// Persist Model
		System.out.println("Persisting data...");
		PersistModel.loadReasonedModel(sharedOwlOutputFileName, directory);
		System.out.println("Operation complete!");
		

	}

}
