package model;

import org.apache.jena.query.Dataset;
import org.apache.jena.query.ReadWrite;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.tdb.TDBFactory;

public class PersistModel {
    
   public static void loadReasonedModel(String turtleFile, String directory){
			    
     System.out.println("Loading turtle model...");
	 //Load Model
	 Model turtleModel = RDFDataMgr.loadModel(turtleFile) ;
	
				
	 // open TDB dataset 
     System.out.println("Setting up serialization...");
	 Dataset dataset = TDBFactory.createDataset(directory);
	 dataset.begin(ReadWrite.WRITE);
			    
	 System.out.println("Serializing model...");
	 dataset.addNamedModel(directory, turtleModel);
	 
	 dataset.commit();
	 dataset.close();
	 turtleModel.close();
			   

	}
}


	
	


