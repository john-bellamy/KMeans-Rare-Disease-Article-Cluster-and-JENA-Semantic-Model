package model;

import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.jena.rdf.model.InfModel;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.reasoner.Reasoner;
import org.apache.jena.reasoner.ReasonerRegistry;
import org.apache.jena.riot.RDFDataMgr;

public class RareDiseaseReasoner {
	public static String defaultNameSpace = "";
	public static Model rdfModel;
	public static Model owlModel;
	public static Model rdfModel2;
	public static Model owlModel2;

	

	
	public static void rdfOwlReasoner(String rdfFile, String rdfFile2, String owlFile, 
			String owlFile2, String outputPath) throws IOException{
	    
      
	//Create Owl and Rdf Models
	   rdfModel = RDFDataMgr.loadModel(rdfFile);
       rdfModel2 = RDFDataMgr.loadModel(rdfFile2);
	   
       owlModel = RDFDataMgr.loadModel(owlFile) ;
	   owlModel2 = RDFDataMgr.loadModel(owlFile2) ;
		
	   System.out.println("Bind first Reasoner...");
	   Reasoner reasoner = ReasonerRegistry.getOWLReasoner(); 
	   reasoner= reasoner.bindSchema(owlModel);
	   
	   System.out.println("Bind second Reasoner...");
	   Reasoner reasoner2 = ReasonerRegistry.getOWLReasoner(); 
	   reasoner2= reasoner2.bindSchema(owlModel2);
	   
	   
	   System.out.println("Create InfoModels...");
		
	   InfModel modelMaker = ModelFactory.createInfModel(reasoner, rdfModel);
	   
	   InfModel modelMaker2 = ModelFactory.createInfModel(reasoner2, rdfModel2);
        
	   //Combine the models
	   modelMaker.add(modelMaker2);

	   FileOutputStream outFile= new FileOutputStream(outputPath);
		
			 
	   System.out.println("Writing model to TURTLE. Please wait...");
	   modelMaker.write(outFile, "TURTLE");
			
	   outFile.close();
		
	   System.out.println("Model written to files.");
		 
	   modelMaker.removeAll();
	   modelMaker2.removeAll();
		 
	   rdfModel.removeAll();
	   owlModel.removeAll();
	   rdfModel2.removeAll();
	   owlModel2.removeAll();
		 
	   System.out.println("Closing Models...");
	   modelMaker.close();
	   rdfModel.close();
	   owlModel.close();
	   modelMaker2.close();
	   rdfModel2.close();
	   owlModel2.close();
					
	   System.out.println("Models Closed :)");
		      
	      
	}

}


