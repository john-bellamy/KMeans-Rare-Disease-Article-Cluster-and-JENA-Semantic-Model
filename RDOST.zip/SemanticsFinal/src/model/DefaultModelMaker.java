package model;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import com.opencsv.CSVReader;


public class DefaultModelMaker{

  private String uri;
  private Model modelName;
  private Property property1;
  private Property property2;
  private Property property3;
  private String[] row = null;
  
  private String property1Name;
  private String property2Name;
  private String property3Name;


    
	public void setUri(String uri){
	this.uri = uri;	
	}
	
	public String getUri(){
	return uri;	
	}
	
	public void setPrefix(String prefix){
		this.modelName.setNsPrefix(prefix , uri );
	}
	

    public void createDefaultModel(Model modelName){
    	this.modelName = ModelFactory.createDefaultModel();
    	
    }
    
    public Model getDefaultModel(){
    return modelName;	
    }
    public void setPropertyName(String property1Name, String property2Name, String property3Name){
    	this.property1Name = property1Name;
    	this.property2Name = property2Name;
    	this.property3Name = property3Name;
    	
    }
    public String getPropertyName(int selection){
    	String name = null;
    	if (selection == 1){
    		name = property1Name;
    	}
    	else if(selection == 2){
    		name = property2Name;
    	}
    	else{
    		name = property3Name;
    	}
		return name;
    	
    }
   
    public void setProperty(Property property1, Property property2, Property property3){
    this.property1 = this.getDefaultModel().createProperty(this.getUri(), getPropertyName(1));
    this.property2 = this.getDefaultModel().createProperty(this.getUri(), getPropertyName(2));
    this.property3 = this.getDefaultModel().createProperty(this.getUri(), getPropertyName(3));
    
    }

	public void readCsv(String csvFileName, String outputPath) throws IOException{
	System.out.println("Reading CSV data...");
	CSVReader csvReader = new CSVReader(new FileReader(csvFileName));
    List<String[]> content = csvReader.readAll();
    
    for (Object object : content) {
	    row = (String[]) object;
			   modelName.createResource(uri + row[0])
			   .addProperty(property1, row[1])
		       .addProperty(property2, row[2])
		       .addProperty(property3, row[3]);	
	
               }
    
	  csvReader.close();
            
	  FileOutputStream modelOut= new FileOutputStream(outputPath);
	    
      //Writes model to turtle:
			
	  System.out.println("Writing model to TURTLEF");
	  modelName.write(modelOut, "TURTLE");

		
	  modelOut.close();
	
	  System.out.println("Model written to files.");
			
	  modelName.removeAll();
	  System.out.println("Closing Model...");
	  modelName.close();
			
	  System.out.println("Model Closed :)");
      }
}


    





